#include "Predicate.h"



Predicate::Predicate()
{
}


Predicate::~Predicate()
{
}
