#include "Rule.h"



Rule::Rule()
{
}


Rule::~Rule()
{
}
