#include "Parameter.h"



Parameter::Parameter()
{
}


Parameter::~Parameter()
{
}
