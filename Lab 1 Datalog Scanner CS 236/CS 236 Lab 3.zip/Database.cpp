#include "Database.h"



Database::Database()
{
}


Database::~Database()
{
}
