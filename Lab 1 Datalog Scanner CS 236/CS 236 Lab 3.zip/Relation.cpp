#include "Relation.h"


Relation::~Relation()
{
}
